
Hey, I'm Pedro St Clair.

This is my personal-portfolio-app/website; and the first I created using Django. I will be building a blog called 'bog'.















By the end, you should be able to:
----------------------------------




  - Understand why it’s a great web framework

  - Understand how it compares with other frameworks

  - See how I built my Django project

  - Build your own Personal Portfolio Website with Django.


















1.



















----------
SIDE NOTE:
----------

I'm assuming you have an intermediate knowledge of the Python language. If you’re new to programming with Python, check out some of the beginner tutorials or the introductory course on Real Python.






Beginner: https://realpython.com/tutorials/basics/
Intro: https://realpython.com/products/real-python-course/


















2.


















"for the lost children..."











                  - Pedro St. Clair




















3.                          



=================
Table of Contents
=================




1. Why Django?
2. The Structure
3. The Build
Hello, World!
Set Up Your Development Environment
Create a Django Project
Create a Django Application
Create a View
Add Bootstrap to Your App
Showcase Your Projects
Projects App: Models
Projects App: Views
Projects App: Templates
Share Your Knowledge With a Blog
Blog App: Models
Blog App: Django Admin
Blog App: Views
Blog App: Templates
Conclusion
References























4.


==============
1. Why Django?
==============



Simple, it’s written in Python, one of the most readable and beginner-friendly programming languages out there. Django is also a fully featured Python web framework that can be used to build complex web applications.

The scope of Django's features are amazing. There is also no need to rely on any external libraries or packages with Django.
Simply put: 'You don’t need to learn how to use anything else'.
The syntax is seamless as you’re using only one framework.

Updating one library or framework will not render others that you’ve installed useless. Very useful, especially if you are a "package-aholic" like myself.

A fantastic range of external libraries that you can use to enhance your site.


https://www.djangoproject.com/ has detailed documentation on every aspect of Django and also has great examples and even a tutorial to get you started.







-----
NOTE:
-----

Django is a high-level web application framework with loads of features. It’s great for anyone new to web development due to its fantastic documentation, and particularly if you’re also familiar with Python.







5.


================
2. The Structure
================



This Django website is very traditional, in the sense that -
It consists of a single project that is split into separate apps.

With that said, There are several different functions that need to be performed:


----------------
User Management:     Login, logout, register, etc
----------------


---------------
The Image Feed:      Uploading, editing, and displaying images
---------------


------------------
Private Messaging:   Private messages between users and   
------------------   notifications



Each are separate 'pieces' of functionality, so in the 'Django-sense', each 'piece' should be a different Django app inside a single Django project.

The project houses configurations applicable to the project as a whole i.e. project settings, URLs, shared templates and static files, etc.

With it's own database, each application has it's own functions to control how data is displayed to the user, by utilising HTML templates.


Besides having their own HTML Templates, each application also has it's own static files, such as JavaScript and CSS





6.







Structured so that there is a separation of logic, Django supports the Model-View-Controller Pattern (most web frameworks are built this way). Basically, the principle is that each application, are three separate files that handle the three main pieces of logic separately:


-----
MODEL
-----
defines the data structure. This is usually a database and is the base layer to an application.

----
VIEW
----
displays some or all of the data to the user with HTML and
CSS.

----------
CONTROLLER
----------
handles how the database and the view interact.

This pattern is know as Model-View-Controller (MVC)




For a more in-depth explanation see:

MVC Explained – With Legos-
https://realpython.com/the-model-view-controller-mvc-paradigm-summarized-with-legos/



















However, In Django, the architecture slightly differs. While based upon the MVC pattern, the controller part is handled by Django itself, Eliminating the need to define how the database and views interact. Done for you by Django.


How convenient!


Django makes use of the Model-View-Template (MVT) pattern. With the view and template in the MVT pattern making up the view in the MVC pattern.

Simply add some URL configurations to map the views to, and Django handles the rest!

Starting off as a project, A Django site is typically built up with a number of applications. Each handling separate functionalities, while following the MVT pattern.

So, now that we are somewhat on the same page of the structure of a Django Site, we move...























8.



============
3. The Build
============

This application contains the following features:


  * A fully functional blog:
    ------------------------

   which will be able to create, update and delete blog posts.
   Posts will have categories that can be used to sort them.
   Finally, users will be able to comments on posts.


   * my portfolio:
    --------------


   To showcase previous web development projects with
   A gallery style page, containing clickable links to
   Completed projects?































==============
ISSUES:
==============


You may encounter bugs, which can be very annoying, especially if you have no idea what's going on. No stress, we have too. Just stay calm, and "know where your towel is".  Here is What I've encountered and how I fixed.



-----
Note:
-----
Solutions are for Mac



1. #HTMLParseError
------------------
"""
deprecated from Python 3.3 onwards and removed in Python 3.5

for more info on html_parse-error:
http://thefourtheye.in/2015/02/15/python-35-and-django-17s-htmlparseerror/

"""


#In that case, perform manual patch of html_parser.py


"""copy or create new file with the code in link below
Locate the html_parser.py file on your system. Then replace. """


#Source code <--- Best Solution
https://github.com/django/django/blob/b07aa52e8a8e4c7fdc7265f75ce2e7992e657ae9/django/utils/html_parser.py


#Django_HTML_tag-parser
https://pypi.org/project/django-tag-parser/





2. ModuleNotFoundError when modifying Django's INSTALLED_APPS?

try:

   'python -m pip install django-cors-headers'


3. popperjs/core error

    I did not have popperjs installed, so I could not install bootstrap,
    went down a bit of a with this journey,





    But wait? Wut? Poppers?

    A popper is an element on the screen which "pops out" from the natural flow of your application.
    Common examples of poppers are tooltips, popovers, and drop-downs.








npm was not working, I might have to reconfigure,


git clone git@github.com:twbs/bootstrap-npm-starter.git


but I used homebrew instead, which proved way more useful.

if you bumped into a similar issue, consider trying this in the terminal:



$ 'brew install amdatu-bootstrap'




(base) skateswtch:psc-portfolio www1$ brew install amdatu-bootstrap
Updating Homebrew...


----------
# Warning:
----------
#You are using macOS 10.13.
#We (and Apple) do not provide support for this old version.
#You will encounter build failures with some formulae.
#Please create pull requests instead of asking for help on Homebrew's GitHub,
#Twitter or any other official channels. You are responsible for resolving
#any issues you experience while you are running this
#old version.

==> Downloading https://raw.githubusercontent.com/macports/macports-ports/edf0ee
######################################################################## 100.0%
==> Downloading https://ftp.gnu.org/gnu/m4/m4-1.4.18.tar.xz
######################################################################## 100.0%
==> Downloading https://ftp.gnu.org/gnu/autoconf/autoconf-2.71.tar.gz
###################################################                       71.1%



4. Npm ERR!

#Useless information

macOS
-----


Download the macOS Installer directly from the nodejs.org web site.

If you want to download the package with bash:

curl "https://nodejs.org/dist/latest/node-${VERSION:-$(wget -qO- https://nodejs.org/dist/latest/ | sed -nE 's|.*>node-(.*)\.pkg</a>.*|\1|p')}.pkg" > "$HOME/Downloads/node-latest.pkg" && sudo installer -store -pkg "$HOME/Downloads/node-latest.pkg" -target "/"
Alternatives
Using Homebrew:

brew install node
Using MacPorts:

port install nodejs<major version>

# Example
port install nodejs7
Using pkgsrc:

Install the binary package:

pkgin -y install nodejs
Or build manually from pkgsrc:

cd pkgsrc/lang/nodejs && bmake install
n
n is a simple to use Node.js version manager for Mac and Linux. Specify the target version to install using a rich syntax, or select from a menu of previously downloaded versions. The versions are installed system-wide or user-wide, and for more targeted use you can run a version directly from the cached downloads.

See the homepage for install methods (boostrap, npm, Homebrew, third-party), and all the usage details.

If you already have npm then installing n and then the newest LTS node version is as simple as:

npm install -g n
n lts
NetBSD
Node.js is available in the pkgsrc tree:

cd /usr/pkgsrc/lang/nodejs && make install
Or install a binary package (if available for your platform) using pkgin:

pkgin -y install nodejs




---> best Solution

I terminal

$ 'git clone git@github.com:twbs/bootstrap-npm-starter.git'




========================================











for more:
https://adamj.eu/tech/2020/06/29/why-does-python-raise-modulenotfounderror-when-modifying-installed-apps/

-----------
REFERENCES:
-----------
Real Python:
https://realpython.com/get-started-with-django-1/

Beginner:
https://realpython.com/tutorials/basics/

Intro:    
https://realpython.com/products/real-python-course/

Django:
https://www.djangoproject.com/

MVCExplained – With Legos:
https://realpython.com/the-model-view-controller-mvc-paradigm-summarized-with-legos/


Django_HTML_tag-parser
https://pypi.org/project/django-tag-parser/


Django html_parser Source code
https://github.com/django/django/blob/b07aa52e8a8e4c7fdc7265f75ce2e7992e657ae9/django/utils/html_parser.py


Django cors-headers
https://adamj.eu/tech/2020/06/29/why-does-python-raise-modulenotfounderror-when-modifying-installed-apps/

npm bootstrap starter
https://git@github.com:twbs/bootstrap-npm-starter.git
